These files contain the necessary information to manufacture
a printed circuit board.

Board Name: Quad Linear Amplifier Board, Rev 1.4
Release Date: 02/12/2016

The files included are:
1-  ReadME.txt      This file
2-  AMP.GTL         Top side routing layer
3-  AMP.GBL         Bottom side routing layer
4-  AMP.GP1         Internal Plane 1
5-  AMP.GP2         Internal Plane 2
6-  AMP.GP3         Internal Plane 3
7-  AMP.G1          Internal Layer 1
8-  AMP.GTO         Top side silk screen mask
9-  AMP.GBO         Bottom side silk screen mask
10- AMP.GTS         Top side solder mask
11- AMP.GBS         Bottom side solder mask
12- AMP-Holes.TXT   Drill file for holes
13- AMP-Slots.TXT   Drill file for slots
14- AMP.IPC         IPC-D-356A Netlist
15- AMP.PDF         Drill and fabrication drawing

NOTE:

1) The Gerber files include RS427X embedded apertures. No separate
   aperture file is provided.

FAB INSTRUCTIONS:
- Vendor and process shall be UL 94V-0 approved.
- Boards must be marked with vender identification and UL 94V-0
- Material: FR4
- Vias: Top-Bottom only.
- Solder mask: LPI   Color: green
- Silkscreen on both sides. Color: white
- Fab tolerance:  See fabrication drawing
- Layer Sequence: See fabrication drawing
- Copper Weight:  See fabrication drawing
- Thickness:      See fabrication drawing
