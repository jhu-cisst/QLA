These files contain the necessary information to assemble a PCB.

Board Name: Quad Linear Amplifier (QLA) Board, Rev 1.2
Release Date: 08/20/2012
Updates:
  * 6/11/2013: Changed R52A-D to 0.0 Ohm

The files included are:
1-  ReadME.txt           This file
2-  QLA.GTP              Top side paste mask
3-  QLA PnP R1_2.CSV     Pick & Place file in CSV format
4-  QLA PnP R1_2.txt     Pick & Place file in Text format
5-  QLA Assy R1_2.pdf    Assembly Drawing

NOTE:

1) The Gerber files include RS427X embedded apertures. No separate
   aperture file is provided.

2) Apertures in the paste mask are the same size as the PCB pads.

3) The CSV and txt files contain the exact same information, just
   in different formats.

4) The Paste Mask file has not changed since Rev 1.0
