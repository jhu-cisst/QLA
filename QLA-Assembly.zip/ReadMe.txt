These files contain the necessary information to assemble a PCB.

Board Name: Quad Linear Amplifier (QLA) Board, Rev 1.6
Release Date: 12/08/2022

The files included are:
1-  ReadME.txt              This file
2-  QLA.GTP                 Top side paste mask
3-  QLA.GBP                 Bottom side paste mask
4-  QLA PnP R1_6.CSV        Pick & Place file in CSV format
5-  QLA PnP R1_6.txt        Pick & Place file in Text format
6-  QLA Assy Rev 1_6.pdf    Assembly Drawing

NOTE:

1) The Gerber files include RS427X embedded apertures. No separate
   aperture file is provided.

2) Apertures in the paste mask are the same size as the PCB pads.

3) The CSV and txt files contain the exact same information, just
   in different formats.
